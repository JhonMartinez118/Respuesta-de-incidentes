/* -----------------------------------------------------------------*
*   INCIAR TODOS LOS REGISTROS DE LAS TABLAS. EJECUTAR POR ORDEN    *
*------------------------------------------------------------------ */
USE UNIVERSIDAD;


/*======================	TABLA DEPENDENCIAS 		=============*/
INSERT INTO uni_dependencias (Clave_Dependencia, Nombre_Dependencia, Direccion)
VALUES 
    ("FCA-C1", "Facultad de Contaduria y Administración Campus I", "Blvd. Belisario Domínguez, km. 1081, Terán, Tuxtla Gutiérrez, Chiapas"), 
    ("FA-C1", "Facultad de Arquitectura Campus I", "Blvd. Belisario Domínguez, km. 1081, Terán, Tuxtla Gutiérrez, Chiapas"), 
    ("FI-C1", "Facultad de Ingeniería Campus I", "Blvd. Belisario Domínguez, km. 1081, Terán, Tuxtla Gutiérrez, Chiapas"), 
    ("FH-C1I", "Facultad de Humanidades Campus II", "HACER UN UPDATE EN ESTE ID, PARA ACTUALIZAR LA DIRECCION");

INSERT INTO uni_dependencias (Clave_Dependencia, Nombre_Dependencia, Direccion)
VALUES ("FMVZ-C1I", "Facultad de Humanidades Campus II", "HACER UN UPDATE EN ESTE ID, PARA ACTUALIZAR LA DIRECCION");


/*======================	TABLA CARRERAS 		=============*/
INSERT INTO UNI_CARRERAS VALUES 
("LC","Licenciatura en Contaduría"),
("LA","Licenciatura en Administración"),
("LGT","Licenciatura en Gestión Turistica "),
("LSC","Licenciatura en Sistemas Computacionales"),
("LIDTS","Lic. en Ingeniería en Desarrollo y Tecnologías de Software"),
("LArq","Licenciatura en Arquitectura"),
("IC","Ingenieria Civil");

/*======================	TABLA MATERIAS 		=============*/
INSERT INTO UNI_MATERIAS VALUES ("LCM011","Fundamentos Administración"),
("LC012","Fundamentos de Contabilidad"),
("LC013","Fundamentos de Derecho"),
("LC014","Gestión del Conocimiento"),
("LC015","Razonamiento Matemático"),
("LC016","Ingles A"),
("LC017","Tecnologías de Información y Comunicación"),

("LIDTS071","Optativa 1 - Seguridad en Cómputo"),
("LIDTS072","Optativa 2 - Analisís de Vulnerabilidades"),
("LIDTS073","Conmutadores y Redes Inalámbricas"),
("LIDTS074","Desarrollo de Aplicaciones Web y Móviles"),
("LIDTS075","Sistemas Operativos"),
("LIDTS076","Inteligencia Ártificial"),
("LIDTS077","Practica Profesional 2"),

("LIDTS081","Optativa 3 - Respuesta a Incidentes de Seguridad"),
("LIDTS082","Optativa 4 - Cómputo Forense"),
("LIDTS083","Optativa 5 - Startup Tecnologicas"),
("LIDTS084","Administración de Sistemas Operativos"),
("LIDTS085","Cómputo distribuido"),
("LIDTS086","Graficacion"),
("LIDTS087","Taller de investigación en las ciencias computacionales");

/*======================	TABLA ALUMNO_MATERIA 		=============*/
INSERT INTO UNI_ALUMNO_CARRERA (Matricula, Clave_Carrera)
VALUES 
    ('A200350', 'LIDTS');

/*======================	TABLA ALUMNOS 		=============*/
INSERT INTO UNI_ALUMNOS (Matricula, Primer_Apellido, Segundo_Apellido, Nombre, CURP, Genero, Estado_Civil, Estado, Municipio, Colonia, Calle, Telefono, Celular, Email, F_Nacimiento, Clave_Dependencia)
VALUES 
    ('A200350', 'Gómez', 'Hernández', 'Julio Manuel', 'GOHJ020412HCSMRLB1', 1, 'Soltero', 'Chiapas', 'Tuxtla Gutierrez', 'Juy Juy', 'Canteras 820', '9672433985', '9672433985', 'julio.gomez99@unach.mx', '2002-04-12', 'FCA-C1');
   /* ('A200369', 'Alvarez', 'Gomez', 'Tomas', 'CURPSI', 1, 'Soltero', 'Chiapas', 'Bochil', '=======', 'S/N', '=======', 'NULO', '2001-03-23', 'FCA-CI'),
    ('A200727', 'Zea', 'Hernández', 'Nestor Horacio', 'CURP', 1, 'Soltero', 'Chiapas', 'Pueblo Nuevo de Solistihuacan', '=====', '=====', 'S/N', '', '2002-07-15', 'FCA-CI'),
    ('A201085', 'Martinez', 'Burciaga', 'Jonathan Isaac', 'MABJ010725HMCRRNA5', 1, 'Soltero', 'Chiapas', 'Tuxtla Gutierrez', '----', '-----', 'S/N', '9611518547', 'jonathan.martinez88@unach.mx', '2001-07-25', 'FCA-CI');*/


INSERT INTO UNI_ALUMNOS (
    Matricula,
    Primer_Apellido,
    Segundo_Apellido,
    Nombre,
    CURP,
    Genero,
    Estado_Civil,
    Estado,
    Municipio,
    Colonia,
    Calle,
    Telefono,
    Celular,
    Email,
    F_Nacimiento,
    Clave_Dependencia
) VALUES (
    'A123456',             -- Matricula
    'Gomez',               -- Primer_Apellido
    'Perez',               -- Segundo_Apellido
    'Julio',               -- Nombre
    'GOPJ890123HDFRRL01',  -- CURP
    1,                     -- Genero (1 para Masculino, 2 para Femenino, o cualquier otro valor según tu configuración)
    'Soltero',             -- Estado_Civil
    'Ciudad de México',    -- Estado
    'Coyoacán',            -- Municipio
    'La Joya',             -- Colonia
    'Av. Siempre Viva 123',-- Calle
    '5551234567',          -- Telefono
    '5557654321',          -- Celular
    'julio@example.com',   -- Email
    '1990-01-23',          -- F_Nacimiento (YYYY-MM-DD)
    'FA-C1'                 -- Clave_Dependencia (clave válida en tu tabla de dependencias)
);


/*======================	TABLA PROFESORES 		=============*/
INSERT INTO UNI_PROFESOR (Clave_Profesor, Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, id_Dependencia)
VALUES 
    ('001', 'SANDOVAL', 'ZUÑIGA', 'LUIS MANUEL', 'manuel.sandoval@unach.mx', '123456789', 1),
    ('010', 'GONZALEZ', 'SORIA', 'MARIANA PAOLA', 'mgonzalez@universidad.com', '-------', 1),
    ('011', 'GUTIERREZ', 'ALFARO', 'LUIS', 'lgutierrez@unach.com', '-------', 1),
    ('012', 'TEVERA', 'MANDUJANO', 'JUAN JOSE', "TEVERA@MANGUJANO.GMAIL", '-----', 1),
    ('002', 'LOPEZ', 'IBAÑEZ', 'GERARDO', 'glopez@unach.com', '-----', 1),
    ('003', 'REGALADO', 'MORENO', 'OBETH', 'obeth.regalado@unach.mx', '----', 1),
    ('004', 'NAÑEZ', 'COUTIÑO', 'ADAN', '--------', '-----', '1'),
    ('005', 'LOPEZ', 'MALDONADO', 'BERNARDO', '----------', '-----', '1'),
    ('006', 'ROMAN', 'JULIAN', 'REBECA', 'rroman@unach.mx', '--------', '1'),
    ('007', 'GUTIERREZ', 'ALFARO', 'LUIS', '---------', '----', '1'),
    ('008', 'RUIZ', 'OVALLE', 'JORGE HUMBERTO', '----------', '------', '1'),
    ('009', 'GONZALEZ', 'SCARPULLI', 'DANIEL', 'Correo@correo.com', '------', '1');

/*======================	TABLA USUARIOS 		=============*/
INSERT INTO USUARIOS (CorreoElectronico, Contrasena, Tipo)
VALUES ('gom_julio12@outlook.com', 'admin123', 'Administrador');
INSERT INTO USUARIOS (CorreoElectronico, Contrasena, Tipo, Clave_Profesor)
VALUES ('profesor1@example.com', 'Profesor123', 'Profesor', '001');
INSERT INTO USUARIOS (CorreoElectronico, Contrasena, Tipo, Matricula)
VALUES ('julio.gomez99@unach.mx', 'password123', 'Alumno', 'A200350');

INSERT INTO USUARIOS (CorreoElectronico, Contrasena, Tipo, Matricula)
VALUES ('jonathan.martinez88@unach.mx', 'password123', 'Administrador', 'A200350');

INSERT INTO USUARIOS (CorreoElectronico, Contrasena, Tipo, Matricula)
VALUES ('julio.gomez99@unach.mx', 'password', 'Administrador', 'A200350');

/*======================	TABLA GRUPOS 		=============*/
INSERT INTO UNI_GRUPOS (Clave_Materia, Clave_Carrera, Clave_Dependencia, Clave_Profesor)
VALUES ('LC012', 'LIDTS', 'FCA-C1', '006'),
       ('LC012', 'LIDTS', 'FCA-C1', '006'),
       ('LC012', 'LIDTS', 'FCA-C1', '006'); 
 
 /*======================	TABLA KARDEX 		=============*/