CREATE DATABASE IF NOT EXISTS UNIVERSIDAD;
USE UNIVERSIDAD;

CREATE TABLE IF NOT EXISTS UNI_DEPENDENCIAS (
    id_Dependencia INT NOT NULL AUTO_INCREMENT,
    Clave_Dependencia VARCHAR(20) NOT NULL,
    Nombre_Dependencia VARCHAR(60) NOT NULL,
    Direccion VARCHAR(100) NOT NULL,
    PRIMARY KEY (id_Dependencia),
    UNIQUE KEY UQ_Clave_Dependencia (Clave_Dependencia)
);

CREATE TABLE IF NOT EXISTS UNI_CARRERAS (
    Clave_Carrera VARCHAR(20) NOT NULL PRIMARY KEY,
    Nombre_Carrera VARCHAR(60) NOT NULL
); 

CREATE TABLE IF NOT EXISTS UNI_MATERIAS (
    Clave_Materia VARCHAR(10) NOT NULL PRIMARY KEY,
    Descripcion VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS UNI_ALUMNOS (
    Matricula VARCHAR(7) NOT NULL PRIMARY KEY,
    Primer_Apellido VARCHAR(50) NOT NULL,
    Segundo_Apellido VARCHAR(50) NOT NULL,
    Nombre VARCHAR(60) NOT NULL,
    CURP VARCHAR(24) NOT NULL,
    Genero INT NOT NULL,
    Estado_Civil VARCHAR(20),
    Estado VARCHAR(50) NOT NULL,
    Municipio VARCHAR(50) NOT NULL,
    Colonia VARCHAR(50),
    Calle VARCHAR(60),
    Telefono VARCHAR(10),
    Celular VARCHAR(10) NOT NULL,
    Email VARCHAR(40),
    F_Nacimiento DATE NOT NULL,
    Clave_Dependencia VARCHAR(20) NOT NULL,
    FOREIGN KEY (Clave_Dependencia) REFERENCES UNI_DEPENDENCIAS(Clave_Dependencia)
);

SELECT Clave_Dependencia, Nombre_dependencia FROM UNI_DEPENDENCIAS;
SELECT Tipo FROM USUARIOS WHERE id;

CREATE TABLE IF NOT EXISTS UNI_PROFESOR (
    Clave_Profesor VARCHAR(10) NOT NULL PRIMARY KEY,
    Primer_Apellido VARCHAR(50) NOT NULL,
    Segundo_Apellido VARCHAR(50) NOT NULL,
    Nombre VARCHAR(50) NOT NULL,
    Email VARCHAR(40) NOT NULL,
    Telefono VARCHAR(10) NOT NULL,
    id_Dependencia INT NOT NULL,
    FOREIGN KEY (id_Dependencia) REFERENCES UNI_DEPENDENCIAS(id_Dependencia)
);



select count(*) from uni_profesor;
SELECT id_Dependencia, Nombre_dependencia FROM UNI_DEPENDENCIAS;
SELECT * FROM UNI_PROFESOR;

CREATE TABLE IF NOT EXISTS UNI_GRUPOS (
    Clave_Grupo INT AUTO_INCREMENT PRIMARY KEY,
    Clave_Materia VARCHAR(10) NOT NULL,
    Clave_Carrera VARCHAR(50) NOT NULL,
    Clave_Dependencia VARCHAR(20) NOT NULL,
    Clave_Profesor VARCHAR(10) NOT NULL,
    FOREIGN KEY (Clave_Materia) REFERENCES UNI_MATERIAS(Clave_Materia),
    FOREIGN KEY (Clave_Carrera) REFERENCES UNI_CARRERAS(Clave_Carrera),
    FOREIGN KEY (Clave_Dependencia) REFERENCES UNI_DEPENDENCIAS(Clave_Dependencia),
    FOREIGN KEY (Clave_Profesor) REFERENCES UNI_PROFESOR(Clave_Profesor)
);

CREATE TABLE IF NOT EXISTS UNI_KARDEX (
    Clave_Kardex INT AUTO_INCREMENT PRIMARY KEY,
    Clave_Grupo INT NOT NULL,
    Matricula VARCHAR(7) NOT NULL,
    Semestre INT NOT NULL,
    Calificacion DECIMAL(18, 0) NOT NULL,
    FOREIGN KEY (Clave_Grupo) REFERENCES UNI_GRUPOS(Clave_Grupo),
    FOREIGN KEY (Matricula) REFERENCES UNI_ALUMNOS(Matricula)
);

CREATE TABLE IF NOT EXISTS UNI_ALUMNO_CARRERA (
    Matricula VARCHAR(7) NOT NULL,
    Clave_Carrera VARCHAR(20) NOT NULL,
    PRIMARY KEY (Matricula, Clave_Carrera),
    FOREIGN KEY (Matricula) REFERENCES UNI_ALUMNOS(Matricula),
    FOREIGN KEY (Clave_Carrera) REFERENCES UNI_CARRERAS(Clave_Carrera)
);

CREATE TABLE IF NOT EXISTS BITACORA(
	id_bitacora int not null primary key AUTO_INCREMENT,
	Host varchar(60),
	Usuario varchar(60),
	Operacion varchar (60),
	Modificado varchar(60),
	Tabla varchar (60)
);

CREATE TABLE USUARIOS (
    ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    CorreoElectronico VARCHAR(100) NOT NULL,
    Contrasena VARCHAR(255) NOT NULL,
    two_factor_secret VARCHAR(32),
    Tipo ENUM('Administrador', 'Profesor', 'Alumno') NOT NULL,    -- Campos específicos para profesores
    Clave_Profesor VARCHAR(10), -- ESTO SE PODRA DEJAR VACIO SI NO LE CORRESPONDE AL USUARIO POR EJEMPLO ALUMNOS
    id_Dependencia INT, -- Campos específicos para alumnos
    Matricula VARCHAR(7),-- ESTO SE PODRA DEJAR VACIO SI NO LE CORRESPONDE AL USUARIO POR EJEMPLO PROFESORES
    FechaRegistro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT UQ_CorreoElectronico UNIQUE (CorreoElectronico),
    -- Restricciones de clave externa
    FOREIGN KEY (Clave_Profesor) REFERENCES UNI_PROFESOR(Clave_Profesor),
    FOREIGN KEY (id_Dependencia) REFERENCES UNI_DEPENDENCIAS(id_Dependencia),
    FOREIGN KEY (Matricula) REFERENCES UNI_ALUMNOS(Matricula)
);

DELIMITER ;;
CREATE DEFINER=`root`@`localhost` TRIGGER `HASH_PASSWORD` BEFORE INSERT ON `usuarios` FOR EACH ROW
BEGIN
    SET NEW.Contrasena = SHA2(NEW.Contrasena, 256);
END ;;
DELIMITER ;

ALTER TABLE USUARIOS ADD COLUMN two_factor_secret VARCHAR(32);
   
    
   SELECT * FROM VISTA_GRUPOS;
   
    CREATE VIEW Vista_Grupos AS
SELECT
    g.Clave_Grupo,
    m.Descripcion AS Materia,
    c.Nombre_Carrera AS Carrera,
    d.Nombre_Dependencia AS Dependencia,
    p.Nombre AS Profesor
FROM
    UNI_GRUPOS g
    INNER JOIN UNI_MATERIAS m ON g.Clave_Materia = m.Clave_Materia
    INNER JOIN UNI_CARRERAS c ON g.Clave_Carrera = c.Clave_Carrera
    INNER JOIN UNI_DEPENDENCIAS d ON g.Clave_Dependencia = d.Clave_Dependencia
    INNER JOIN UNI_PROFESOR p ON g.Clave_Profesor = p.Clave_Profesor;


/* **********************************************************************************************
* 			  			     TODAS LAS VISTAS CREADAS DE LAS TABLAS				   			    *
*********************************************************************************************** */

-- ******************  Vista para Profesores *********************
CREATE VIEW VW_Profesor2 AS
SELECT 
	p.clave_profesor,
    p.Nombre,
    p.Primer_Apellido,
    p.Segundo_Apellido,
    p.Email,
    p.Telefono,
    d.Nombre_Dependencia AS Dependencia
FROM 
    UNI_PROFESOR p
INNER JOIN 
    UNI_DEPENDENCIAS d ON p.id_Dependencia = d.id_Dependencia;
SELECT * FROM VW_Profesor2;

CREATE VIEW VW_Alumnos AS
SELECT 
    Matricula,
    Nombre,
    Primer_Apellido,
    Segundo_Apellido,
    CURP,
    Calle,
    Colonia,
    Municipio,
    Estado,
    Celular,
    Email,
    F_Nacimiento,
    ud.Nombre_Dependencia AS Nombre_Dependencia
FROM 
    UNI_ALUMNOS ua
JOIN 
    UNI_DEPENDENCIAS ud ON ua.Clave_Dependencia = ud.Clave_Dependencia
ORDER BY Nombre ASC; -- Orden ascendente por nombre

-- ESTA VISTA NO ES NECESARIO QUE LO CREAN, NO SE UTILIZA EN LA APLICACION WEB.
CREATE VIEW VW_AlumnosII AS
SELECT 
    Matricula,
    Nombre,
    CONCAT(Primer_Apellido, ' ', Segundo_Apellido) AS Apellidos,
    CURP,
    CONCAT(Calle, ', ', Colonia, ', ', Municipio, ', ', Estado) AS Direccion,
    Celular,
    Email,
    F_Nacimiento,
    ud.Nombre_Dependencia AS Nombre_Dependencia
FROM 
    UNI_ALUMNOS ua
JOIN 
    UNI_DEPENDENCIAS ud ON ua.Clave_Dependencia = ud.Clave_Dependencia
ORDER BY Nombre ASC; -- Orden ascendente por nombre

    SELECT * FROM VW_Alumnos;
    
    
CREATE VIEW Vista_Alumnos AS
SELECT 
    a.Nombre,
    u.CorreoElectronico AS Correo,
    'México' AS Pais, -- Se asume que todos los alumnos son de México
    a.Municipio
FROM 
    UNI_ALUMNOS a
JOIN 
    USUARIOS u ON a.Matricula = u.Matricula
WHERE 
    u.Tipo = 'Alumno';


