USE UNIVERSIDAD;

-- ****************************************************************
--         TRIGGER PARA ENCRIPTAR LA CONTRASEÑA AL REGISTRARSE
-- ****************************************************************
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` TRIGGER `HASH_PASSWORD` BEFORE INSERT ON `usuarios` FOR EACH ROW
BEGIN
    SET NEW.Contrasena = SHA2(NEW.Contrasena, 256);
END ;;
DELIMITER ;

-- ****************************************************************
-- TRIGGER TABLA DEPENDENCIAS
-- ****************************************************************
DELIMITER //
CREATE TRIGGER BIT_INSERT_DEPENDENCIA
AFTER INSERT ON uni_dependencias
FOR EACH ROW 
INSERT INTO BITACORA (Host,Usuario, Operacion, Modificado, Tabla)
VALUES (SUBSTRING(USER(), INSTR(USER(), "@") + 1),
        SUBSTRING(USER(), 1, INSTR(USER(), "@") - 1),
        'INSERTAR', 
        NOW(),
        'Dependencia');
DELIMITER;

-- Trigger para UPDATE en uni_dependencias
CREATE TRIGGER BIT_UPDATE_DEPENDENCIA
AFTER UPDATE ON uni_dependencias
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING(USER(), INSTR(USER(), "@") + 1),
    SUBSTRING(USER(), 1, INSTR(USER(), "@") - 1),
    'ACTUALIZAR',
    NOW(),
    'Dependencia'
);

-- Trigger para DELETE en uni_dependencias
CREATE TRIGGER BIT_DELETE_DEPENDENCIA
AFTER DELETE ON uni_dependencias
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING(USER(), INSTR(USER(), "@") + 1),
    SUBSTRING(USER(), 1, INSTR(USER(), "@") - 1),
    'ELIMINAR',
    NOW(),
    'Dependencia'
);

-- ****************************************************************
-- TRIGGER TABLA CARRERAS
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_CARRERAS
AFTER INSERT ON UNI_CARRERAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'CARRERAS'
);

-- Trigger para UPDATE en UNI_CARRERAS
CREATE TRIGGER BIT_UPDATE_CARRERAS
AFTER UPDATE ON UNI_CARRERAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'CARRERAS'
);

-- Trigger para DELETE en UNI_CARRERAS
CREATE TRIGGER BIT_DELETE_CARRERAS
AFTER DELETE ON UNI_CARRERAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'CARRERAS'
);

-- ****************************************************************
-- TRIGGER TABLA MATERIAS
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_MATERIAS
AFTER INSERT ON UNI_MATERIAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'MATERIAS'
);

-- Trigger para UPDATE en UNI_MATERIAS
CREATE TRIGGER BIT_UPDATE_MATERIAS
AFTER UPDATE ON UNI_MATERIAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'MATERIAS'
);

-- Trigger para DELETE en UNI_MATERIAS
CREATE TRIGGER BIT_DELETE_MATERIAS
AFTER DELETE ON UNI_MATERIAS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'MATERIAS'
);

-- ****************************************************************
-- 					TRIGGER TABLA ALUMNOS 
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_ALUMNOS
AFTER INSERT ON UNI_ALUMNOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'ALUMNOS'
);

-- Trigger para UPDATE en UNI_ALUMNOS
CREATE TRIGGER BIT_UPDATE_ALUMNOS
AFTER UPDATE ON UNI_ALUMNOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'ALUMNOS'
);

-- Trigger para DELETE en UNI_ALUMNOS
CREATE TRIGGER BIT_DELETE_ALUMNOS
AFTER DELETE ON UNI_ALUMNOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'ALUMNOS'
);

-- ****************************************************************
-- TRIGGER TABLA PROFESOR
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_PROFESOR
AFTER INSERT ON UNI_PROFESOR
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'PROFESOR'
);

-- Trigger para UPDATE en UNI_PROFESOR
CREATE TRIGGER BIT_UPDATE_PROFESOR
AFTER UPDATE ON UNI_PROFESOR
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'PROFESOR'
);

-- Trigger para DELETE en UNI_PROFESOR
CREATE TRIGGER BIT_DELETE_PROFESOR
AFTER DELETE ON UNI_PROFESOR
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'PROFESOR'
);

-- ****************************************************************
-- TRIGGER TABLA GRUPOS
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_GRUPOS
AFTER INSERT ON UNI_GRUPOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'GRUPOS'
);

-- Trigger para UPDATE en UNI_GRUPOS
CREATE TRIGGER BIT_UPDATE_GRUPOS
AFTER UPDATE ON UNI_GRUPOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'GRUPOS'
);

-- Trigger para DELETE en UNI_GRUPOS
CREATE TRIGGER BIT_DELETE_GRUPOS
AFTER DELETE ON UNI_GRUPOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'GRUPOS'
);

-- ****************************************************************
-- TRIGGER TABLA KARDEX
-- ****************************************************************
CREATE TRIGGER BIT_INSERT_KARDEX
AFTER INSERT ON UNI_KARDEX
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'KARDEX'
);

-- Trigger para DELETE en UNI_KARDEX
CREATE TRIGGER BIT_DELETE_KARDEX
AFTER DELETE ON UNI_KARDEX
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'KARDEX'
);

-- Trigger para UPDATE en UNI_KARDEX
CREATE TRIGGER BIT_UPDATE_KARDEX
AFTER UPDATE ON UNI_KARDEX
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'KARDEX'
);

-- ****************************************************************
-- TRIGGER TABLA ALUMNO_CARRERA
-- ****************************************************************
-- Trigger para INSERT en USUARIOS
CREATE TRIGGER BIT_INSERT_ALUMNO_CARRERA
AFTER INSERT ON UNI_ALUMNO_CARRERA
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'ALUMNO_CARRERA'
);

-- Trigger para DELETE en UNI_ALUMNO_CARRERA
CREATE TRIGGER BIT_DELETE_ALUMNO_CARRERA
AFTER DELETE ON UNI_ALUMNO_CARRERA
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'ALUMNO_CARRERA'
);

-- Trigger para UPDATE en UNI_ALUMNO_CARRERA
CREATE TRIGGER BIT_UPDATE_ALUMNO_CARRERA
AFTER UPDATE ON UNI_ALUMNO_CARRERA
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'ALUMNO_CARRERA'
);

-- ****************************************************************
-- TRIGGER TABLA USUARIOS
-- ****************************************************************

-- Trigger para INSERT en USUARIOS
CREATE TRIGGER BIT_INSERT_USUARIOS
AFTER INSERT ON USUARIOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'INSERTAR',
    NOW(),
    'USUARIOS'
);

-- Trigger para UPDATE en USUARIOS
CREATE TRIGGER BIT_UPDATE_USUARIOS
AFTER UPDATE ON USUARIOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ACTUALIZAR',
    NOW(),
    'USUARIOS'
);

-- Trigger para DELETE en USUARIOS
CREATE TRIGGER BIT_DELETE_USUARIOS
AFTER DELETE ON USUARIOS
FOR EACH ROW 
INSERT INTO BITACORA (Host, Usuario, Operacion, Modificado, Tabla)
VALUES (
    SUBSTRING_INDEX(USER(), '@', -1),
    SUBSTRING_INDEX(USER(), '@', 1),
    'ELIMINAR',
    NOW(),
    'USUARIOS'
);

DROP TRIGGER BIT_DELETE_USUARIOS; BIT_UPDATE_USUARIOS, BIT_INSERT_USUARIOS;


