# DOCUMENTACIÓN

instalar virtualenv

 ```powershell
pip install virtualenv
 ```

crear un entorno virtual

 ```powershell
python -m venv env
 ```

Activar el entorno virtual

 ```powershell
env\Scripts\activate
 ```

 si sale un error que la ejecución de scripts está deshabilitada en tu sistema, hacemos lo siguiente abrimos powershell como administrador y ejecutamos el siguiente comando.

 ```powershell
Set-ExecutionPolicy RemoteSigned
 ```

## INSTALAR FLASK

INSTALAR LAS LIBRERIAS EJECUTANDO EL REQUIREMENTS.TXT

¿Cómo ejecutar el requirements?

 ```powershell
pip install -r requirements.txt
 ```
 
```
└── 📁Res_Incidentes_Proyect
    └── 📁Database
        └── Registros.sql
        └── Script Base de datos.sql
        └── Triggers.sql
    └── 📁env
    └── readme.md
    └── requirements.txt
    └── 📁src
        └── App.py
        └── 📁Backend
            └── 📁Administrador
                └── adminController.py
                └── admin_routes.py
            └── 📁Auth
                └── Autenticacion.py
                └── Auth_routes.py
            └── 📁database
                └── bd.py
            └── 📁Estudiantes
                └── estudiante_routes.py
            └── 📁Profesores
                └── profesorcontroller.py
                └── profesor_routes.py
            └── Role.py
        └── config.py
        └── Pruebas.py
        └── 📁static
            └── 📁bootstrap
                └── 📁css
                └── 📁js
            └── 📁bootstrap-icons
                └── 📁fonts
                    └── bootstrap-icons.woff
                    └── bootstrap-icons.woff2
            └── 📁css
                └── style.css
                └── styleadmin.css
                └── styleteacher.css
            └── 📁img
                └── error_403.png
                └── error_404.png
                └── favicon.ico
                └── Imglogin.png
                └── perfil.webp
            └── 📁js
                └── adminjs.js
                └── Auth.js
                └── teacherjs.js
        └── 📁templates
            └── 📁admin
                └── 📁adminstudent
                    └── alumnoAgregar.html
                    └── registrados.html
                └── 📁adminteacher
                    └── agregarprofesor.html
                    └── Registrados.html
                └── Base_Dashboard.html
                └── 📁Bitacora
                    └── bitacora.html
            └── 📁Alumno
                └── index.html
                └── modperfil.html
                └── perfilalumno.html
            └── 📁Auth
                └── Login.html
                └── Verificar.html
            └── 📁Error
                └── error_403.html
                └── error_404.html
            └── 📁Profesores
                └── header.html
                └── profesor.html
            └── prueba.html
```