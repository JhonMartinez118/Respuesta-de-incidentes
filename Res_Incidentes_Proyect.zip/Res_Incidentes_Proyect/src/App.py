from flask import Flask
from Backend.Auth.Auth_routes import Auth_bp
from Backend.Administrador.admin_routes import Admin_bp
from Backend.Profesores.profesor_routes import Profesor_bp
from Backend.Estudiantes.estudiante_routes import Estudiante_bp
from flask_mail import Mail, Message # Libreria para enviar correos ---> pip install Flaks_Mail

app = Flask(__name__)

# Configuración de la clave secreta
app.secret_key = 'tu_clave_secreta_aqui'

# Registrar blueprints
app.register_blueprint(Auth_bp)
app.register_blueprint(Admin_bp)
app.register_blueprint(Profesor_bp)
app.register_blueprint(Estudiante_bp)

if __name__ == '__main__':
    app.run(debug=True)