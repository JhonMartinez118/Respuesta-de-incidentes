from Backend.database.bd import crearConexionBD
db = crearConexionBD()

def consultar_profesores():
    cursor = db.cursor()
    cursor.execute("SELECT COUNT(*) AS total_profesores FROM uni_profesor;")
    total_profesores = cursor.fetchone()[0]
    cursor.close()
    return total_profesores

def consultar_Alumnos():
    cursor = db.cursor()
    cursor.execute("SELECT COUNT(*) AS total_alumnos FROM uni_alumnos;")
    total_alumnos = cursor.fetchone()[0]
    cursor.close()
    return total_alumnos

def dependencias():
    # Consulta SQL para obtener las dependencias
    cursor = db.cursor()
    cursor.execute("SELECT id_Dependencia, Nombre_Dependencia FROM UNI_DEPENDENCIAS")
    ListaDependencias = cursor.fetchall()
    cursor.close()
    return ListaDependencias

def dependenciasClave():
    # Consulta SQL para obtener las dependencias
    cursor = db.cursor()
    cursor.execute("SELECT clave_Dependencia, Nombre_Dependencia FROM UNI_DEPENDENCIAS")
    ClaveDependencias = cursor.fetchall()
    cursor.close()
    return ClaveDependencias