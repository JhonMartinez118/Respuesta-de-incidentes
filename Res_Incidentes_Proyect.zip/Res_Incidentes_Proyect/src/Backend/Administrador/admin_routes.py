from flask import Blueprint, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQLdb
from Backend.database.bd import crearConexionBD
from Backend.Role import role_required
from Backend.Administrador.adminController import *
from Backend.Auth.Auth_routes import logout

Admin_bp = Blueprint('Admin_bp', __name__)
db = crearConexionBD()

@Admin_bp.route('/administrator')
@role_required('Administrador')
def administrator():
    if 'usuario_id' in session:
        cursor = db.cursor()
        try:
            query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            tipo_usuario = cursor.fetchone()[0]
            if tipo_usuario == 'Administrador':
                # Aquí puedes agregar lógica adicional específica para el panel de administrador
                total_profesores = consultar_profesores()  # Obtener el total de profesores
                total_alumnos = consultar_Alumnos()
                variables = {
                    'total_docentes': total_profesores,
                    'total_alumnos': total_alumnos,
                }
                return render_template('admin/Base_Dashboard.html', **variables, active_tab='dashboard')
            else:
                return redirect(url_for('error403'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        print(role_required())
        return redirect(url_for('index'))
    
@Admin_bp.route('/administrator/profesores')
@role_required('Administrador')
def ProfesoresRegistrado():
    # Obtener datos de profesores
    cursor = db.cursor()
    cursor.execute("SELECT * FROM VW_Profesor2")
    profesores = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in profesores:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    total_profesores = consultar_profesores()
    variables = {
        'total_docentes': total_profesores,
        'data': insertObject
    }    
    return render_template('admin/adminteacher/registrados.html', active_tab='profesores', **variables)

@Admin_bp.route('/EliminarProfesor/<string:id>')
@role_required('Administrador')
def EliminarProfesor(id):
    cursor = db.cursor()
    sql = "DELETE FROM UNI_PROFESOR WHERE Clave_Profesor = %s"
    data = (id,)
    cursor.execute(sql, data)
    db.commit()
    return redirect(url_for('Admin_bp.ProfesoresRegistrado'))

# Apartado para Modificar Los datos de los pacientes
@Admin_bp.route('/ModificarProfesor/<string:clave_profesor>', methods=['POST'])
@role_required('Administrador')
def ModificarProfesor(clave_profesor):
    Primer_Apellido = request.form['Primer_Apellido']
    Segundo_Apellido = request.form['Segundo_Apellido']
    Nombre = request.form['Nombre']
    Email = request.form['Email']
    Telefono = request.form['Telefono']
    # id_Dependecia = request.form['id_Dependencia']

    if Primer_Apellido and Segundo_Apellido and Nombre and Email and Telefono :
        cursor = db.cursor()
        sql = "UPDATE UNI_PROFESOR SET Primer_Apellido = %s, Segundo_Apellido = %s, Nombre = %s, Email = %s, Telefono = %s WHERE Clave_Profesor = %s"
        data = (Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, clave_profesor)
        cursor.execute(sql, data)
        db.commit()
    return redirect(url_for('Admin_bp.ProfesoresRegistrado')) #(home) <--- es la funcion donde retorna al actualizar

@Admin_bp.route('/administrator/profesores-add')
@role_required('Administrador')
def AgregarProfesor():
    total_profesores = consultar_profesores()
    ListaDependencias = dependencias()
    variables = {
        'total_docentes': total_profesores,
        'dependencias': ListaDependencias
    } 
    return render_template('/admin/adminteacher/agregarprofesor.html', active_tab='AgregarProfesor',  **variables)

@Admin_bp.route('/Agregar_Profesor', methods=['GET', 'POST'])
def agregar_profesor():
    if request.method == 'POST':
        ClaveProfesor = request.form['Clave_Profesor']
        Nombre = request.form['Nombre']
        Primer_Apellido = request.form['Primer_Apellido']
        Segundo_Apellido = request.form['Segundo_Apellido']
        Email = request.form['Email']
        Telefono = request.form['Telefono']
        Dependencia = request.form['Dependencia']

        if ClaveProfesor and Primer_Apellido and Segundo_Apellido and Nombre and Email and Telefono and Dependencia:
            cursor = db.cursor()
            sql = "INSERT INTO UNI_PROFESOR (Clave_Profesor, Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, id_Dependencia) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            data = (ClaveProfesor, Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, Dependencia)
            cursor.execute(sql, data)
            db.commit()
            cursor.close()
        return redirect(url_for('Admin_bp.ProfesoresRegistrado'))


# ********************************************************************************
#               PROCEDIMIENTOS Y VISTAS DEL PANEL DE REGISTRO DE ESTUDIANTES EN ADMIN
# ********************************************************************************

@Admin_bp.route('/administrator/alumnos')
@role_required('Administrador')
def AlumnoRegistrados():
    # Obtener datos de Alumnos
    cursor = db.cursor()
    cursor.execute("SELECT * FROM VW_Alumnos")
    Alumnos = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in Alumnos:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    total_alumnos = consultar_Alumnos()
    variables = {
        'total_alumnos': total_alumnos,
        'data': insertObject
    }    
    return render_template('/admin/adminstudent/registrados.html', active_tab='AlumnosRegistrados',  **variables)

# # RUTA Y FUNCION PARA MODIFICAR LOS DATOS DE LOS ESTUDIANTES
@Admin_bp.route('/ModificarAlumno/<string:matricula>', methods=['POST'])
def ModificarAlumno(matricula):
    Primer_Apellido = request.form['Primer_Apellido']
    Segundo_Apellido = request.form['Segundo_Apellido']
    Nombre = request.form['Nombre']
    CURP = request.form['CURP']
    Celular = request.form['Celular']
    Email = request.form['Email']
    Calle = request.form['Calle']
    Colonia = request.form['Colonia']
    Municipio = request.form['Municipio']
    Estado = request.form['Estado']
    F_Nacimiento = request.form['F_Nacimiento']
    # Clave_Dependencia = request.form['Clave_Dependencia']

    if Primer_Apellido and Segundo_Apellido and Nombre and CURP and Celular and Email and Calle and Colonia and Municipio and Estado and F_Nacimiento:
        cursor = db.cursor()
        sql = """
        UPDATE UNI_ALUMNOS 
        SET 
            Primer_Apellido = %s, 
            Segundo_Apellido = %s, 
            Nombre = %s, 
            CURP = %s, 
            Celular = %s, 
            Email = %s, 
            Calle = %s, 
            Colonia = %s, 
            Municipio = %s, 
            Estado = %s, 
            F_Nacimiento = %s
        WHERE Matricula = %s
        """
        data = (Primer_Apellido, Segundo_Apellido, Nombre, CURP, Celular, Email, Calle, Colonia, Municipio, Estado, F_Nacimiento, matricula)
        cursor.execute(sql, data)
        db.commit()
    return redirect(url_for('Admin_bp.AlumnoRegistrados')) 

@Admin_bp.route('/administrator/alumnos-add')
@role_required('Administrador')
def AgregarAlumnos():
   total_alumnos = consultar_Alumnos()
   ClaveDependencias = dependenciasClave()
   variables = {
        'total_alumnos': total_alumnos,
        'dependencias1': ClaveDependencias
    }
   return render_template('/admin/adminstudent/alumnoAgregar.html', active_tab='AgregarAlumno',  **variables)

@Admin_bp.route('/Agregar_Alumno', methods=['GET', 'POST'])
def agregar_alumno():
    if request.method == 'POST':
        Matricula = request.form['Matricula']
        Primer_Apellido = request.form['Primer_Apellido']
        Segundo_Apellido = request.form['Segundo_Apellido']
        Nombre = request.form['Nombre']
        CURP = request.form['CURP']
        Genero = request.form['Genero']
        Estado_Civil = request.form['Estado_Civil']
        Estado = request.form['Estado']
        Municipio = request.form['Municipio']
        Colonia = request.form['Colonia']
        Calle = request.form['Calle']
        Telefono = request.form['Telefono']
        Celular = request.form['Celular']
        Email = request.form['Email']
        F_Nacimiento = request.form['F_Nacimiento']
        Clave_Dependencia = request.form['Clave_Dependencia']

        if Matricula and Primer_Apellido and Segundo_Apellido and Nombre and CURP and Genero and Estado and Municipio and Celular and F_Nacimiento and Clave_Dependencia:
            try:
                cursor = db.cursor()
                sql = """
                INSERT INTO UNI_ALUMNOS (Matricula, Primer_Apellido, Segundo_Apellido, Nombre, CURP, Genero, Estado_Civil, Estado, Municipio, Colonia, Calle, Telefono, Celular, Email, F_Nacimiento, Clave_Dependencia) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                data = (Matricula, Primer_Apellido, Segundo_Apellido, Nombre, CURP, Genero, Estado_Civil, Estado, Municipio, Colonia, Calle, Telefono, Celular, Email, F_Nacimiento, Clave_Dependencia)
                cursor.execute(sql, data)
                db.commit()
                return redirect(url_for('Admin_bp.AlumnoRegistrados'))
            except MySQLdb.OperationalError as e:
                print(f"Error de conexión a la base de datos: {e}")
                # Aquí puedes implementar una lógica de reintento o simplemente cerrar la conexión
                cursor.close()
                return "Error de conexión a la base de datos, por favor intente de nuevo más tarde."
        else:
            return "Faltan datos requeridos en el formulario."
    return render_template('/admin/adminstudent/alumnoAgregar.html' )

@Admin_bp.route('/administrator/bitacora')
@role_required('Administrador')
def Bitacoras():
    # Obtener datos de profesores
    cursor = db.cursor()
    cursor.execute("SELECT * FROM bitacora")
    profesores = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in profesores:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    variables = {
        'data': insertObject
    }    
    return render_template('admin/Bitacora/bitacora.html', active_tab='profesores', **variables)



@Admin_bp.route('/logout')
def logout_route():
    return logout()
  

