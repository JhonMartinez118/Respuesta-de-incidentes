from flask import session

def autenticacion():
    return 'usuario_id' in session