from flask import Blueprint, render_template, request, redirect, url_for, session
from Backend.database.bd import crearConexionBD
from Backend.Administrador.adminController import *
import hashlib
import requests
import pyotp
import smtplib

Auth_bp = Blueprint('Auth_bp', __name__)
db = crearConexionBD()

@Auth_bp.route('/')
def index():
    return render_template('auth/Login.html')


# @Auth_bp.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         correo = request.form['correo']
#         contrasena = request.form['contrasena']
#         hashed_password = hashlib.sha256(contrasena.encode()).hexdigest()
#         db = crearConexionBD()

#         try:
#             cursor = db.cursor()
#             query = "SELECT * FROM USUARIOS WHERE CorreoElectronico = %s AND Contrasena = %s"
#             cursor.execute(query, (correo, hashed_password))
#             usuario = cursor.fetchone()

#             if usuario:
#                 session['usuario_id'] = usuario[0]
#                 if usuario[3] == 'Administrador':
#                     return redirect(url_for('Admin_bp.administrator'))
#                 elif usuario[3] == 'Profesor':
#                     return redirect(url_for('profesor_bp.Profesor'))
#                 elif usuario[3] == 'Alumno':
#                     return redirect(url_for('Estudiante_bp.Alumno'))
#             else:
#                 return render_template('auth/Login.html', error="Credenciales incorrectas. Inténtalo de nuevo.")
#         except Exception as e:
#             return str(e)
#         finally:
#             cursor.close()
#             db.close()

#     return render_template('auth/Login.html')
@Auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form['correo']
        contrasena = request.form['contrasena']
        hashed_password = hashlib.sha256(contrasena.encode()).hexdigest()
        db = crearConexionBD()

        try:
            cursor = db.cursor()
            query = "SELECT * FROM USUARIOS WHERE CorreoElectronico = %s AND Contrasena = %s"
            cursor.execute(query, (correo, hashed_password))
            usuario = cursor.fetchone()

            if usuario:
                # Guardar el correo del usuario en sesión
                session['correo_verificar'] = correo
                # Generar y enviar código de verificación
                if not usuario[3]:  # Verificar si el usuario tiene un secreto de 2FA
                    secret = pyotp.random_base32()
                    cursor.execute("UPDATE USUARIOS SET two_factor_secret = %s WHERE CorreoElectronico = %s", (secret, correo))
                    db.commit()
                else:
                    secret = usuario[3]

                totp = pyotp.TOTP(secret)
                codigo = totp.now()

                # Enviar el código por correo electrónico
                enviar_codigo_por_correo(correo, codigo)

                return redirect(url_for('Auth_bp.verificar'))

            else:
                return render_template('auth/Login.html', error="Credenciales incorrectas. Inténtalo de nuevo.")
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
            db.close()

    return render_template('auth/Login.html')


@Auth_bp.route('/verificar', methods=['GET', 'POST'])
def verificar():
    if request.method == 'POST':
        codigo = request.form['codigo']
        correo = session.get('correo_verificar')

        if not correo:
            return redirect(url_for('auth.login'))

        db = crearConexionBD()

        try:
            cursor = db.cursor()
            query = "SELECT * FROM USUARIOS WHERE CorreoElectronico = %s"
            cursor.execute(query, (correo,))
            usuario = cursor.fetchone()

            if usuario:
                totp = pyotp.TOTP(usuario[3]) # Obtener la longitud del secreto
                if totp.verify(codigo):
                    session['usuario_id'] = usuario[0]
                    session.pop('correo_verificar', None)  # Eliminar la sesión temporal

                    if usuario[4] == 'Administrador':
                        return redirect(url_for('Admin_bp.administrator'))
                    elif usuario[4] == 'Profesor':
                        return redirect(url_for('profesor_bp.Profesor'))
                    elif usuario[4] == 'Alumno':
                        return redirect(url_for('Estudiante_bp.Alumno'))
                    else:
                        return render_template('auth/verificar.html', error="Código incorrecto. Inténtalo de nuevo.")
                else:
                    return render_template('auth/verificar.html', error="Código incorrecto. Inténtalo de nuevo.")
            else:
                return redirect(url_for('auth.login'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
            db.close()

    return render_template('auth/verificar.html')


def enviar_codigo_por_correo(correo, codigo):
    remitente = 'juliogome47@gmail.com'
    receptor = correo
    contraseña = 'gzie tvqf mhds iyzv'
    mensaje = f"Tu código de verificación es {codigo}"

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(remitente, contraseña)

            mensaje_codificado = mensaje.encode('utf-8')
            server.sendmail(remitente, receptor, mensaje_codificado)
        print("Correo enviado correctamente")
    except Exception as e: 
        print(f"Error al enviar el correo: {e}")



def logout():
    session.clear()
    return redirect(url_for('Auth_bp.index'))
