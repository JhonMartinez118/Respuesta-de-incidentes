from flask import Blueprint, render_template, request, redirect, url_for, session
from Backend.database.bd import crearConexionBD

Estudiante_bp = Blueprint('Estudiante_bp', __name__)
db = crearConexionBD()


def infoalumno():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM  vista_alumnos;")
    info_alumno = cursor.fetchone()[0]
    cursor.close()
    return  info_alumno

# RUTA PARA ENTRAR EN EL PANEL DE ALUMNOS
@Estudiante_bp.route('/alumno')
def Alumno():
    if 'usuario_id' in session:
        cursor = db.cursor()
        try:
            query = "SELECT * FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            alumno = cursor.fetchone()
            if alumno:

                infoalumnos= infoalumno()
                variables = {'datosalumno': infoalumnos}
                # Pasar los datos del alumno a la plantilla
                return render_template('Alumno/perfilalumno.html', alumno=alumno, **variables)
            else:
                return render_template('Alumno/perfilalumno.html', alumno=alumno, **variables)
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        return redirect(url_for('index'))
    

