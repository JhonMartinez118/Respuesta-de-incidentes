from flask import Blueprint, render_template, request, redirect, url_for, session
from Backend.database.bd import crearConexionBD

db = crearConexionBD()

Profesor_bp = Blueprint('profesor_bp', __name__)

# RUTA PARA ENTRAR EN EL PANEL DE PROFESOR
@Profesor_bp.route('/teacher')
def Profesor():
    if 'usuario_id' in session:
        # Verifica si el usuario ha iniciado sesión
        cursor = db.cursor()
        try:
            query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            tipo_usuario = cursor.fetchone()[0]
            if tipo_usuario == 'Profesor':
                # Aquí puedes agregar lógica adicional específica para el panel de profesor
                return render_template('Profesores/header.html')
            else:
                return redirect(url_for('error403'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        return redirect(url_for('index'))