from flask import session, redirect, url_for, flash
from functools import wraps
from Backend.database.bd import crearConexionBD
db = crearConexionBD()

def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'usuario_id' not in session:
                return redirect(url_for('Auth_bp.login'))

            cursor = None
            try:
                cursor = db.cursor()
                query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
                cursor.execute(query, (session['usuario_id'],))
                tipo_usuario = cursor.fetchone()
                if tipo_usuario is None or tipo_usuario[0] != role:
                    flash("Acceso denegado: no tiene permiso para acceder a esta página.", "error")
                    return redirect(url_for('error403'))
                return f(*args, **kwargs)
            except Exception as e:
                return str(e)
            finally:
                if cursor:
                    cursor.close()
        return decorated_function
    return decorator