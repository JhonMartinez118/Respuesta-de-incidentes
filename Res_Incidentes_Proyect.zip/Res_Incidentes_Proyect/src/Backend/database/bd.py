import mysql.connector
from mysql.connector import Error

# CONFIGURACION DE LA CONEXIÓN A MYSQL
def crearConexionBD():
    Conexion = None
    try:
        Conexion = mysql.connector.connect(
            host='localhost',
            user='root',
            password='Gomez_2002.',
            database='universidad'
        )
        if Conexion.is_connected():
            print("Conexión exitosa a la base de datos")
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
    return Conexion
