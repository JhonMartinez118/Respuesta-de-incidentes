from flask import Flask, render_template, send_from_directory,session,redirect,url_for,request, flash
from flask_mysqldb import MySQL, MySQLdb
from config import Config
import hashlib
from Backend.Role import role_required

app = Flask(__name__)
mysql = MySQL(app)
app.config.from_object(Config)


@app.route('/')
def index():
    return render_template('/Auth/Login.html')


@app.route('/alumno')
def alumno():
    return render_template('/Student/index.html')

# =================== PROTECCION DE RUTAS =====================================
def autenticacion():
    return 'usuario' in session

# MANEJARR EXCEPCIONES
@app.errorhandler(Exception)
def handle_database_errors(error):
    # SI OCURRE UN ERROR CERRAR LA BASE DE DATOS.
    if hasattr(mysql, 'connection') and mysql.connection is not None:
        mysql.connection.close()
    return 'Error en la base de datos: ' + str(error), 500

# RUTA PARA INICIO DE SESIÓN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form['correo']
        contrasena = request.form['contrasena']
        hashed_password = hashlib.sha256(contrasena.encode()).hexdigest()
        cursor = mysql.connection.cursor()
        
        try:
            query = "SELECT * FROM USUARIOS WHERE CorreoElectronico = %s AND Contrasena = %s"
            cursor.execute(query, (correo, hashed_password))
            usuario = cursor.fetchone()
            
            if usuario:
                session['usuario_id'] = usuario[0] 
                if usuario[3] == 'Administrador':
                    return redirect(url_for('administrator'))
                elif usuario[3] == 'Profesor':
                    return redirect(url_for('teacher'))
                # elif usuario[3] == 'Alumno':
                #     return redirect(url_for('student'))
            else:
                # Enviar mensaje de error al renderizar la plantilla
                return render_template('/Auth/Login.html', error="Credenciales incorrectas. Inténtalo de nuevo.")
        except Exception as e:
            return str(e)
        finally:
            if cursor:
                cursor.close()
            if mysql.connection:
                mysql.connection.close()

    return render_template('/Auth/Login.html')

# RUTA PARA ENTRAR EN EL PANEL DE ADMINISTRADOR
@app.route('/administrator')
def administrator():
    if 'usuario_id' in session:
        cursor = mysql.connection.cursor()
        try:
            query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            tipo_usuario = cursor.fetchone()[0]
            if tipo_usuario == 'Administrador':
                # Aquí puedes agregar lógica adicional específica para el panel de administrador
                total_profesores = consultar_profesores()  # Obtener el total de profesores
                total_alumnos = consultar_Alumnos()
                variables = {
                    'total_docentes': total_profesores,
                    'total_alumnos': total_alumnos,
                }
                return render_template('admin/dashboard.html', **variables, active_tab='dashboard')
            else:
                return redirect(url_for('error403'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        print(role_required())
        return redirect(url_for('index'))

# RUTA PARA ENTRAR EN EL PANEL DE PROFESOR
@app.route('/teacher')
def teacher():
    if 'usuario_id' in session:
        # Verifica si el usuario ha iniciado sesión
        cursor = mysql.connection.cursor()
        try:
            query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            tipo_usuario = cursor.fetchone()[0]
            if tipo_usuario == 'Profesor':
                # Aquí puedes agregar lógica adicional específica para el panel de profesor
                return render_template('teacher.html')
            else:
                return redirect(url_for('error403'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        return redirect(url_for('index'))

# RUTA PARA ENTRAR EN EL PANEL DE ALUMONOS
@app.route('/student')
def student():
    if 'usuario_id' in session:
        # Verifica si el usuario ha iniciado sesión
        cursor = mysql.connection.cursor()
        try:
            query = "SELECT Tipo FROM USUARIOS WHERE id = %s"
            cursor.execute(query, (session['usuario_id'],))
            tipo_usuario = cursor.fetchone()[0]
            if tipo_usuario == 'Alumno':
                # Aquí puedes agregar lógica adicional específica para el panel de alumno
                return render_template('student.html')
            else:
                return redirect(url_for('error403'))
        except Exception as e:
            return str(e)
        finally:
            cursor.close()
    else:
        return redirect(url_for('index'))

# RUTA PARA ENTRAR EN EL PANEL DE ALUMNOS
# @app.route('/student')
# def student():
#     if 'usuario_id' in session:
#         cursor = mysql.connection.cursor()
#         try:
#             query = "SELECT * FROM Uni_Alumnos WHERE Matricula = %s"
#             cursor.execute(query, (session['usuario_id'],))
#             alumno = cursor.fetchone()
#             if alumno:
#                 # Pasar los datos del alumno a la plantilla
#                 return render_template('student/index.html', alumno=alumno)
#             else:
#                 return render_template('student/index.html', alumno=alumno)
#         except Exception as e:
#             return str(e)
#         finally:
#             cursor.close()
#     else:
#         return redirect(url_for('index'))

# RUTA PARA CERRAR SESION Y LIMPIAR LA SESION
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


# ********************************************************************************
#               MANEJO DE ERRORES 404 Y PERMISO DENEGADO
# ********************************************************************************
# ERROR 403
@app.errorhandler(403)
def forbidden_error(error):
    return render_template('/Error/error_403.html'), 403

# ERROR 404
@app.errorhandler(404)
def page_not_found(e):
    return render_template('/Error/error_404.html'), 404

@app.route('/error403')
def error403():
    return render_template('/Error/error_403.html')


# ********************************************************************************
#               FUNCIONES PARA MOSTRAR EN EN PANEL DE ADMINISTRADOR
# ********************************************************************************
def consultar_profesores():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT COUNT(*) AS total_profesores FROM uni_profesor;")
    total_profesores = cursor.fetchone()[0]
    cursor.close()
    return total_profesores

def consultar_Alumnos():
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT COUNT(*) AS total_profesores FROM uni_alumnos;")
    total_alumnos = cursor.fetchone()[0]
    cursor.close()
    return total_alumnos

def dependencias():
    # Consulta SQL para obtener las dependencias
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT id_Dependencia, Nombre_Dependencia FROM UNI_DEPENDENCIAS")
    ListaDependencias = cursor.fetchall()
    cursor.close()
    return ListaDependencias

# ********************************************************************************
#               PROCEDIMIENTOS Y VISTAS DEL PANEL DE REGISTRO DE MAESTROS EN ADMIN
# ********************************************************************************

@app.route('/administrator/profesores')
@role_required('Administrador')
def ProfesoresRegistrado():
    # Obtener datos de profesores
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM VW_Profesor2")
    profesores = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in profesores:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    total_profesores = consultar_profesores()
    variables = {
        'total_docentes': total_profesores,
        'data': insertObject
    }    
    print(dependencias())
    return render_template('admin/adminteacher/registrados.html', active_tab='profesores', **variables)

@app.route('/EliminarProfesor/<string:id>')
@role_required('Administrador')
def EliminarProfesor(id):
    cur = mysql.connection.cursor()
    sql = "DELETE FROM UNI_PROFESOR WHERE Clave_Profesor = %s"
    data = (id,)
    cur.execute(sql, data)
    mysql.connection.commit()
    return redirect(url_for('ProfesoresRegistrado'))

# Apartado para Modificar Los datos de los pacientes
@app.route('/ModificarProfesor/<string:clave_profesor>', methods=['POST'])
@role_required('Administrador')
def ModificarProfesor(clave_profesor):
    Primer_Apellido = request.form['Primer_Apellido']
    Segundo_Apellido = request.form['Segundo_Apellido']
    Nombre = request.form['Nombre']
    Email = request.form['Email']
    Telefono = request.form['Telefono']
    # id_Dependecia = request.form['id_Dependencia']

    if Primer_Apellido and Segundo_Apellido and Nombre and Email and Telefono :
        cur = mysql.connection.cursor()
        sql = "UPDATE UNI_PROFESOR SET Primer_Apellido = %s, Segundo_Apellido = %s, Nombre = %s, Email = %s, Telefono = %s WHERE Clave_Profesor = %s"
        data = (Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, clave_profesor)
        cur.execute(sql, data)
        mysql.connection.commit()
    return redirect(url_for('ProfesoresRegistrado')) #(home) <--- es la funcion donde retorna al actualizar

@app.route('/administrator/profesores-add')
@role_required('Administrador')
def AgregarProfesor():
    total_profesores = consultar_profesores()
    ListaDependencias = dependencias()
    variables = {
        'total_docentes': total_profesores,
        'dependencias': ListaDependencias
    } 
    return render_template('/admin/adminteacher/agregarprofesor.html', active_tab='AgregarProfesor',  **variables)

@app.route('/Agregar_Profesor', methods=['GET', 'POST'])
def agregar_profesor():
    if request.method == 'POST':
        ClaveProfesor = request.form['Clave_Profesor']
        Nombre = request.form['Nombre']
        Primer_Apellido = request.form['Primer_Apellido']
        Segundo_Apellido = request.form['Segundo_Apellido']
        Email = request.form['Email']
        Telefono = request.form['Telefono']
        Dependencia = request.form['Dependencia']

        if ClaveProfesor and Primer_Apellido and Segundo_Apellido and Nombre and Email and Telefono and Dependencia:
            cursor = mysql.connection.cursor()
            sql = "INSERT INTO UNI_PROFESOR (Clave_Profesor, Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, id_Dependencia) VALUES (%s, %s, %s, %s, %s, %s, %s)"
            data = (ClaveProfesor, Primer_Apellido, Segundo_Apellido, Nombre, Email, Telefono, Dependencia)
            cursor.execute(sql, data)
            mysql.connection.commit()
            cursor.close()
        return redirect(url_for('ProfesoresRegistrado'))

# ********************************************************************************
#               PROCEDIMIENTOS Y VISTAS DEL PANEL DE REGISTRO DE ESTUDIANTES EN ADMIN
# ********************************************************************************

@app.route('/administrator/alumnos')
@role_required('Administrador')
def AlumnoRegistrados():
    # Obtener datos de Alumnos
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM VW_Alumnos")
    Alumnos = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in Alumnos:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    total_alumnos = consultar_Alumnos()
    variables = {
        'total_alumnos': total_alumnos,
        'data': insertObject
    }    
    return render_template('/admin/adminstudent/registrados.html', active_tab='AlumnosRegistrados',  **variables)


# # RUTA Y FUNCION PARA MODIFICAR LOS DATOS DE LOS ESTUDIANTES
@app.route('/ModificarAlumno/<string:matricula>', methods=['POST'])
def ModificarAlumno(matricula):
    Primer_Apellido = request.form['Primer_Apellido']
    Segundo_Apellido = request.form['Segundo_Apellido']
    Nombre = request.form['Nombre']
    CURP = request.form['CURP']
    Celular = request.form['Celular']
    Email = request.form['Email']
    Calle = request.form['Calle']
    Colonia = request.form['Colonia']
    Municipio = request.form['Municipio']
    Estado = request.form['Estado']
    F_Nacimiento = request.form['F_Nacimiento']
    # Clave_Dependencia = request.form['Clave_Dependencia']

    if Primer_Apellido and Segundo_Apellido and Nombre and CURP and Celular and Email and Calle and Colonia and Municipio and Estado and F_Nacimiento:
        cur = mysql.connection.cursor()
        sql = """
        UPDATE UNI_ALUMNOS 
        SET 
            Primer_Apellido = %s, 
            Segundo_Apellido = %s, 
            Nombre = %s, 
            CURP = %s, 
            Celular = %s, 
            Email = %s, 
            Calle = %s, 
            Colonia = %s, 
            Municipio = %s, 
            Estado = %s, 
            F_Nacimiento = %s
        WHERE Matricula = %s
        """
        data = (Primer_Apellido, Segundo_Apellido, Nombre, CURP, Celular, Email, Calle, Colonia, Municipio, Estado, F_Nacimiento, matricula)
        cur.execute(sql, data)
        mysql.connection.commit()
    return redirect(url_for('AlumnoRegistrados')) 

@app.route('/administrator/alumnos-add')
@role_required('Administrador')
def AgregarAlumnos():
   total_alumnos = consultar_Alumnos()
   variables = {
        'total_alumnos': total_alumnos,
    }
   return render_template('/admin/adminstudent/alumnoAgregar.html', active_tab='AgregarAlumno',  **variables)

@app.route('/Agregar_Alumno', methods=['GET', 'POST'])
def agregar_alumno():
    if request.method == 'POST':
        Matricula = request.form['Matricula']
        Primer_Apellido = request.form['Primer_Apellido']
        Segundo_Apellido = request.form['Segundo_Apellido']
        Nombre = request.form['Nombre']
        CURP = request.form['CURP']
        Genero = request.form['Genero']
        Estado_Civil = request.form['Estado_Civil']
        Estado = request.form['Estado']
        Municipio = request.form['Municipio']
        Colonia = request.form['Colonia']
        Calle = request.form['Calle']
        Telefono = request.form['Telefono']
        Celular = request.form['Celular']
        Email = request.form['Email']
        F_Nacimiento = request.form['F_Nacimiento']
        Clave_Dependencia = request.form['Clave_Dependencia']

        if Matricula and Primer_Apellido and Segundo_Apellido and Nombre and CURP and Genero and Estado and Municipio and Celular and F_Nacimiento and Clave_Dependencia:
            try:
                cursor = mysql.connection.cursor()
                sql = """
                INSERT INTO UNI_ALUMNOS (Matricula, Primer_Apellido, Segundo_Apellido, Nombre, CURP, Genero, Estado_Civil, Estado, Municipio, Colonia, Calle, Telefono, Celular, Email, F_Nacimiento, Clave_Dependencia) 
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                data = (Matricula, Primer_Apellido, Segundo_Apellido, Nombre, CURP, Genero, Estado_Civil, Estado, Municipio, Colonia, Calle, Telefono, Celular, Email, F_Nacimiento, Clave_Dependencia)
                cursor.execute(sql, data)
                mysql.connection.commit()
                return redirect(url_for('AlumnosRegistrados'))
            except MySQLdb.OperationalError as e:
                print(f"Error de conexión a la base de datos: {e}")
                # Aquí puedes implementar una lógica de reintento o simplemente cerrar la conexión
                cursor.close()
                return "Error de conexión a la base de datos, por favor intente de nuevo más tarde."
        else:
            return "Faltan datos requeridos en el formulario."
    return render_template('/admin/adminstudent/alumnoAgregar.html')























# # FUNCION PARA ELIMINAR ALGUN ESTUDIANTE
# @app.route('/EliminarProfesor/<string:id>')
# def EliminarProfesor(id):
#     cur = mysql.connection.cursor()
#     sql = "DELETE FROM UNI_PROFESOR WHERE Clave_Profesor = %s"
#     data = (id,)
#     cur.execute(sql, data)
#     mysql.connection.commit()
#     return redirect(url_for('index'))










@app.route('/administrator/pruebas')
def pruebas():
    return render_template('admin/adminstudent/registrados.html')


if __name__ == '__main__':
    app.run()
