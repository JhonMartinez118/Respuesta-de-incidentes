class Config:
    DEBUG = True
    SECRET_KEY = 'ClaveSecreta.1'
    
    # CONFIGURACIÓN DE LA BASE DE DATOS MySQL
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'zelda118'
    MYSQL_DB = 'universidad'
