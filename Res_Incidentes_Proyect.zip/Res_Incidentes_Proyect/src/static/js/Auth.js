document.getElementById('loginForm').addEventListener('submit', function(event) {
      const correo = document.getElementById('email').value;
      const contrasena = document.getElementById('contrasena').value;
      const mensajeError = document.getElementById('mensaje-error');

      if (!correo || !contrasena) {
          event.preventDefault(); // Prevenir el envío del formulario
          mensajeError.textContent = 'Por favor, complete todos los campos.';
          mensajeError.classList.add('d-block');
      }
  });

  document.getElementById('email').addEventListener('input', function () {
      var correo = document.getElementById('email');
      var MenCorreo = document.getElementById('Alert');
      var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (correo.value.trim() === '') {
          MenCorreo.textContent = 'Por favor llena los campos'
          MenCorreo.removeAttribute('hidden');
      } else {
          if (emailRegex.test(correo.value.trim())) {
              MenCorreo.setAttribute('hidden', 'true');
          } else {
              MenCorreo.textContent = 'Por favor ingresa un correo válido'
              MenCorreo.removeAttribute('hidden');
          }
      }
  });

  document.getElementById('contrasena').addEventListener('input', function () {
      var contraseña = document.getElementById('contrasena');
      var MenContra = document.getElementById('MenContra');
      var contraRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%?&])[A-Za-z\d@$!%?&]{8,10}$/;

      if (contraseña.value.trim() === '') {
          MenContra.textContent = 'No puede quedar vacio'
          MenContra.removeAttribute('hidden');
      } else {
          if (contraRegex.test(contraseña.value.trim())) {
              MenContra.setAttribute('hidden', 'true');
          } else {
              MenContra.textContent = 'Debe tener 8 caracteres, Minuscular, Mayusculas y numeros'
              MenContra.removeAttribute('hidden');
          }
      }
  });