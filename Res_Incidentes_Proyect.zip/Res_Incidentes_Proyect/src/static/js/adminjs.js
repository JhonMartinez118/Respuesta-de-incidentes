const sidebarToggle = document.querySelector("#sidebar-toggle");
sidebarToggle.addEventListener("click",function(){
    document.querySelector("#sidebar").classList.toggle("collapsed");
});

function loadHTML(htmlFile) {
    fetch(htmlFile)
    .then(response => response.text())
    .then(data => {
        document.getElementById('main-content').innerHTML = data;
    })
    .catch(error => console.error('Error al cargar el HTML:', error));
}

document.getElementById('email').addEventListener('input', function () {
    var correo = document.getElementById('email');
    var MenCorreo = document.getElementById('Alert');
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (correo.value.trim() === '') {
        MenCorreo.textContent = 'Por favor llena los campos'
        MenCorreo.removeAttribute('hidden');
    } else {
        if (emailRegex.test(correo.value.trim())) {
            MenCorreo.setAttribute('hidden', 'true');
        } else {
            MenCorreo.textContent = 'Por favor ingresa un correo válido'
            MenCorreo.removeAttribute('hidden');
        }
    }
});